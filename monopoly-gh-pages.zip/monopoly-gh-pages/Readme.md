#monopoly

This is a basic JavaScript/HTML/CSS Monopoly implementation. Up to eight players can play at once. If you're familiar with Monopoly, game play should be fairly self-explanatory. But if you have trouble, hovering the mouse over a control will usually display more information. Please report any issues you find.

Play online at [https://intrepidcoder.github.io/monopoly/](https://intrepidcoder.github.io/monopoly/) or [http://www.intrepidcoder.com/projects/monopoly/](http://www.intrepidcoder.com/projects/monopoly/) (alternate version).

New: Added capability to play against an AI. A AI for demonstration purposes only is included. A future update will include a more realistic opponent.
